ZED! LIMITED EDITION 2025.1 

On system Ubuntu 24.04, use installer in "Ubuntu 24.04" folder.
On system Ubuntu 22.04, use installer in "Ubuntu 22.04" folder.

Copyright Prim'X Technologies.